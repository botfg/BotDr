from setuptools import setup, find_packages
from os.path import join, dirname
import os
import sys
import BotDr



if sys.version_info < (3, 6, 0):
    sys.stderr.write("ERROR: You need Python 3.6 or later to use BotDr.\n")
    exit(1)

setup(
    name='BotDr',
    author='botfg76',
    author_email='botfgbartenevfgzero76@gmail.com',
    license='Apache License Version 2.0',
    url='https://github.com/botfg/BotDr',
    description='Birth date control',
    long_description=open(join(dirname(__file__), 'README.txt')).read(),
    version=BotDr.__version__,
    packages=find_packages(),
    scripts=['BotDr/BotDr.py'],
    install_requires=[
        'pysqlcipher3==1.0.3',
        'numpy==1.17.4',
        'pyAesCrypt==0.4.3'],
    python_requires=">=3.6",
    include_package_data=True,
    package_data={
        'BotDr': ['*.db', '*.csv', '*.csv.aes'],
    },
    entry_points={
        'console_scripts':
            ['BotDr = BotDr:super_main']
        }
    
)