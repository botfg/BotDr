Description
===========


Need to install system libraries: sqlcipher libsqlcipher0 libsqlcipher-dev

debian: sudo apt install sqlcipher libsqlcipher0 libsqlcipher-dev


BotDr - python3 console script for working with birthday dates supporting local accounts

This program calculates the number of days before a birthday knowing the date of birth.

You can also get information about the number of birthdays before the end of the year, etc.

Accounts are portable and encrypted